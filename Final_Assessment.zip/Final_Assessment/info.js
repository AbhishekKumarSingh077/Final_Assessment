function formValidation() {
    return validateFname();
}

function validateFname() {
    var allAlpha = true;
    var elem = document.querySelector("#firstName");
    var inputValue = elem.value.trim();
    inputValue = inputValue.toUpperCase();

    for (var i = 0; i < inputValue.length; i++) {
         // check all characters are letters
         if (inputValue.charAt(i) < "A" || inputValue.charAt(i) > "Z" )  { allAlpha = false; }
    }  
   
    if (!allAlpha){
         alert("Name : Please enter a meaningful name with all alphabet letters.");
         elem.focus();
         return false;
    } 
    return true;
} 

